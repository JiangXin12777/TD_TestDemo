#include "TD_ConfigManagerLog.h"

DEFINE_LOG_CATEGORY(TD_ConfigManagerLog);