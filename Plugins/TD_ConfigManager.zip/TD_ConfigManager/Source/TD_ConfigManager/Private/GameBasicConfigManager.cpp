#include "GameBasicConfigManager.h"
#include "GameBasicConfigStructureBlueprint.h"
#include "GameBasicConfigStructureConverter.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Serialization/Csv/CsvParser.h"

FGameBasicConfigManager::FGameBasicConfigManager()
{

}

FGameBasicConfigManager* FGameBasicConfigManager::Get()
{
	static FGameBasicConfigManager Instance;
	return &Instance;
}

UObject* FGameBasicConfigManager::LoadConfigRow(FString ConfigRowURL)
{
	TArray<FAssetData> AssetDataList;
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
	AssetRegistry.GetAssetsByPath(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), AssetDataList, true, true);
	for (auto AssetData : AssetDataList) {
#if WITH_EDITOR
		if (AssetData.AssetClassPath.ToString() == UGameBasicConfigStructureBlueprint::StaticClass()->GetPathName()) {
			UGameBasicConfigStructureBlueprint* BP = LoadObject<UGameBasicConfigStructureBlueprint>(nullptr, *AssetData.GetObjectPathString());
			UClass* Class = BP->GeneratedClass;
#else
		if (AssetData.AssetClassPath.ToString() == UBlueprintGeneratedClass::StaticClass()->GetPathName()) {
			UClass* Class = LoadObject<UClass>(nullptr, *AssetData.GetObjectPathString());
#endif
			FString URL = Class->GetPackage()->GetPathName()
				.Replace(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), TEXT(""))
				.TrimChar(TCHAR('/'))
				.Replace(TEXT("/"), TEXT("."));
			if (ConfigRowURL.StartsWith(URL)|| ConfigRowURL.StartsWith(URL.Replace(TEXT("DC_"),TEXT("")))) {
				FString LuaPath = UGameBasicConfigStructureBlueprint::GetConfigDataDir() / Class->GetName().LeftChop(2) + ".lua";
				auto ConfigData = FLuaTable::CreateFromFile(LuaPath);
				TSharedPtr<FLuaTable> Data = ConfigData->FindOrReturn("Data", ELuaValueType::Table)->AsTable();
				TSharedPtr<FLuaTable> Header = ConfigData->FindOrReturn("Column", ELuaValueType::Table)->AsTable();
				if (URL.Contains(TEXT("DC_")) && !ConfigRowURL.Contains(TEXT("DC_")))
					URL.ReplaceInline(TEXT("DC_"), TEXT(""));
				FString MainKey = ConfigRowURL.Replace(*(URL + "."), TEXT(""));
				if (Data->Contains(MainKey)) {
					TSharedPtr<FLuaTable> RowData = Data->FindOrReturn(MainKey, ELuaValueType::Table)->AsTable();
					UObject* NewInstance = NewObject<UObject>(GetTransientPackage(), Class);
					FGameBasicConfigStructureConverter::GameBasicConfigToUObject(Header, RowData, NewInstance);
					return NewInstance;
				}
			}
		}
	}
	return nullptr;
}

TArray<UObject*> FGameBasicConfigManager::LoadConfigTable(FString ConfigURL)
{
	TArray<UObject*> Instances;
	TArray<FAssetData> AssetDataList;
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
	AssetRegistry.GetAssetsByPath(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), AssetDataList, true);
	for (auto AssetData : AssetDataList) {
#if WITH_EDITOR
		if (AssetData.AssetClassPath.ToString() == UGameBasicConfigStructureBlueprint::StaticClass()->GetPathName()) {
			UGameBasicConfigStructureBlueprint* BP = LoadObject<UGameBasicConfigStructureBlueprint>(nullptr, *AssetData.GetObjectPathString());
			UClass* Class = BP->GeneratedClass;
#else
		if (AssetData.AssetClassPath.ToString() == UBlueprintGeneratedClass::StaticClass()->GetPathName()) {
			UClass* Class = LoadObject<UClass>(nullptr, *AssetData.GetObjectPathString());
#endif
			FString URL = Class->GetPackage()->GetPathName()
				.Replace(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), TEXT(""))
				.TrimChar(TCHAR('/'))
				.Replace(TEXT("/"), TEXT("."));
			if (URL == ConfigURL || URL.Replace(TEXT("DC_"),TEXT("")) == ConfigURL) {
				FString LuaPath = UGameBasicConfigStructureBlueprint::GetConfigDataDir() / Class->GetName().LeftChop(2) + ".lua";
				auto ConfigData = FLuaTable::CreateFromFile(LuaPath);
				TSharedPtr<FLuaTable> Data = ConfigData->FindOrReturn("Data", ELuaValueType::Table)->AsTable();
				TSharedPtr<FLuaTable> Header = ConfigData->FindOrReturn("Column", ELuaValueType::Table)->AsTable();
				for (auto Row : *Data) {
					TSharedPtr<FLuaTable> RowData = Row.Value->AsTable();
					if (RowData) {
						UObject* NewInstance = NewObject<UObject>(GetTransientPackage(), Class);
						FGameBasicConfigStructureConverter::GameBasicConfigToUObject(Header, RowData, NewInstance);
						Instances.Add(NewInstance);
					}
				}
			}
		}
	}
	return Instances;
}

TMap<int32, UObject*> FGameBasicConfigManager::LoadConfigTableByRemark(FString CsvURL, FString ConfigURL)
{
	TMap<int32, UObject*> Instances;
	TArray<FAssetData> AssetDataList;
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
	AssetRegistry.GetAssetsByPath(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), AssetDataList, true);
	for (auto AssetData : AssetDataList)
	{
#if WITH_EDITOR
		if (AssetData.AssetClassPath.ToString() == UGameBasicConfigStructureBlueprint::StaticClass()->GetPathName()) {
			UGameBasicConfigStructureBlueprint* BP = LoadObject<UGameBasicConfigStructureBlueprint>(nullptr, *AssetData.GetObjectPathString());
			UClass* Class = BP->GeneratedClass;
#else
		if (AssetData.AssetClassPath.ToString() == UBlueprintGeneratedClass::StaticClass()->GetPathName()) {
			UClass* Class = LoadObject<UClass>(nullptr, *AssetData.GetObjectPathString());
#endif
			FString FileContent;
			FString URL = Class->GetPackage()->GetPathName()
			.Replace(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), TEXT(""))
			.TrimChar(TCHAR('/'))
			.Replace(TEXT("/"), TEXT("."));
			if (URL == ConfigURL || URL.Replace(TEXT("DC_"),TEXT("")) == ConfigURL)
			{
				if(FFileHelper::LoadFileToString(FileContent,*CsvURL))
				{
					const FCsvParser Parser(FileContent);
					const FCsvParser::FRows& Rows = Parser.GetRows();
					
					int32 Index = 0;
					for(TArray<const TCHAR*> Row:Rows)
					{
						FString ColumnData = Row[0];
						if(ColumnData.Contains(TEXT("#")))
						{
							UObject* Obj = NewObject<UObject>(GetTransientPackage(), Class);
							FStrProperty* StrProperty = FindFProperty<FStrProperty>(Obj->GetClass(),TEXT("Remark"));
							if(StrProperty && StrProperty->HasAnyPropertyFlags(CPF_Transient))
							{
								StrProperty->SetValue_InContainer(Obj, ColumnData);
								Instances.FindOrAdd(Index) = Obj;
							}
						}
						Index++;
					}
				}
			}
		}
	}
	return Instances;
}