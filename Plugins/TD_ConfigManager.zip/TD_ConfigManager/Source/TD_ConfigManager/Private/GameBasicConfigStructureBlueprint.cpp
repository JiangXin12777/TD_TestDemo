#include "GameBasicConfigStructureBlueprint.h"

#if WITH_EDITOR
bool UGameBasicConfigStructureBlueprint::SupportedByDefaultBlueprintFactory() const
{
	return false;
}

bool UGameBasicConfigStructureBlueprint::AlwaysCompileOnLoad() const
{
	return false;
}

bool UGameBasicConfigStructureBlueprint::Rename(const TCHAR* NewName /*= nullptr*/, UObject* NewOuter /*= nullptr*/, ERenameFlags Flags /*= REN_None*/)
{
	FString OldCsvPath = GetCsvFilePath();
	FString OldLuaPath = GetLuaFilePath();
	bool Ret = Super::Rename(NewName, NewOuter, Flags);
	FString NewCsvPath = GetCsvFilePath();
	FString NewLuaPath = GetLuaFilePath();
	if (OldLuaPath != NewLuaPath) {
		IFileManager::Get().Move(*OldLuaPath, *NewLuaPath);
	}
	if (OldCsvPath != NewCsvPath) {
		IFileManager::Get().Move(*OldCsvPath, *NewCsvPath);
	}
	return Ret;
}
#endif

FString UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath()
{
	return "/Game/Config";
}

FString UGameBasicConfigStructureBlueprint::GetConfigStructureDir()
{
	FString ContentPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*FPaths::ProjectContentDir());
	return ContentPath / "Config";
}

FString UGameBasicConfigStructureBlueprint::GetConfigSourceDir()
{
	const auto PathWithProjectDir = FPaths::Combine(FPaths::ProjectDir(), "KulangsuData/Data");
	return FPaths::ConvertRelativePathToFull(PathWithProjectDir);
}

FString UGameBasicConfigStructureBlueprint::GetConfigDataDir()
{
	const auto PathWithProjectDir = FPaths::Combine(FPaths::ProjectContentDir(), "Script/Config");
	return FPaths::ConvertRelativePathToFull(PathWithProjectDir);
}

FString UGameBasicConfigStructureBlueprint::GetExportToolPath()
{
	const auto PathWithProjectDir = FPaths::Combine(FPaths::ProjectDir(), "KulangsuData/Tools/CsvExport/main.exe");
	return FPaths::ConvertRelativePathToFull(PathWithProjectDir);
}

FString UGameBasicConfigStructureBlueprint::GetCsvFilePath()
{
	return GetConfigSourceDir() / GetName() + ".csv";
}

FString UGameBasicConfigStructureBlueprint::GetLuaFilePath()
{
	return GetConfigDataDir() / GetName() + ".lua";
}

FString UGameBasicConfigStructureBlueprint::GetConfigUrl()
{
	return GetPackage()->GetPathName()
		.Replace(*GetConfigStructurePackagePath(), TEXT(""))
		.TrimChar(TCHAR('/'))
		.Replace(TEXT("/"), TEXT("."));
}
