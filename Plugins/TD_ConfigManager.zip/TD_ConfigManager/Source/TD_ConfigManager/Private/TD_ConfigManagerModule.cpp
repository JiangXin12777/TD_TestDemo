// Copyright Epic Games, Inc. All Rights Reserved.

#include "TD_ConfigManagerModule.h"

#include "TD_ConfigManager.h"

#define LOCTEXT_NAMESPACE "FTD_ConfigManagerModule"

void FTD_ConfigManagerModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FTD_ConfigManagerModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FTD_ConfigManagerModule, TD_ConfigManager)