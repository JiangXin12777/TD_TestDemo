#include "GameBasicAssetManager.h"

UGameBasicAssetManager::UGameBasicAssetManager()
{

}

FString UGameBasicAssetManager::GetDataAssetDir()
{
	return "/Game/Script/DataAsset";
}

FString UGameBasicAssetManager::GetPrimaryDataAssetTemplateDir(UObject* DataAssetClass)
{
	FString PackageDir = GetDataAssetDir() / DataAssetClass->GetName();
	FString TemplateDir = FPaths::ProjectContentDir() + PackageDir.Mid(6, PackageDir.Len() - 6);
	FString AbsPath = IFileManager::Get().ConvertToAbsolutePathForExternalAppForRead(*TemplateDir);
	return AbsPath;
}

TArray<FString> UGameBasicAssetManager::GetPrimaryDataAssetInstancePaths(UBlueprint* DataAssetBlueprint)
{
	TArray<FString> Instances;
	FString TemplateDir = GetPrimaryDataAssetTemplateDir(DataAssetBlueprint->GeneratedClass);
	IFileManager::Get().IterateDirectory(*TemplateDir, [&Instances](const TCHAR* Pathname, bool bIsDirectory) {
		if (!bIsDirectory) {
			FString Ext = FPaths::GetExtension(Pathname);
			FString BaseName = FPaths::GetBaseFilename(Pathname);
			if (Ext == "lua") {
				Instances.Add(Pathname);
			}
		}
		return true;
	});
	return Instances;
}
