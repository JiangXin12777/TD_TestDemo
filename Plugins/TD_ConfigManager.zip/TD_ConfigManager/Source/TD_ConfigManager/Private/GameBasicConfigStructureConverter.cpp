﻿#include "GameBasicConfigStructureConverter.h"
#include "GameBasicLogDefine.h"
#include "LuaTable/LuaTable.h"

#if WITH_EDITOR
void FGameBasicConfigStructureConverter::UPropertyToGameBasicConfig(FProperty* Property, const void* Value, TArray<FGameBasicConfigCellData>& Row, FString PrePath /*= ""*/, FProperty* OuterProperty /*= nullptr*/)
{
	FString PropertyPath = FLuaTableConverter::GetPropertyName(Property->GetOwner<UStruct>(), Property);
	if (!PrePath.IsEmpty())
		PropertyPath = FString::Printf(TEXT("%s.%s"), *PrePath, *PropertyPath);
	FGameBasicConfigCellData CellData;
	CellData.Name = PropertyPath;
	CellData.Desc = Property->GetToolTipText().ToString();
	CellData.ExportType = FGameBasicConfigCellData::EExportType::C;
	if (Property->HasMetaData("ServerVariable")) {
		CellData.ExportType = FGameBasicConfigCellData::EExportType::CS;
	}
	else if (Property->HasMetaData("ServerOnlyVariable")) {
		CellData.ExportType = FGameBasicConfigCellData::EExportType::S;
	}
	if (FEnumProperty* EnumProperty = CastField<FEnumProperty>(Property)) {
		if (EnumProperty->HasMetaData("ExportEnumValue")
			|| (EnumProperty->GetOwnerProperty() && EnumProperty->GetOwnerProperty()->HasMetaData("ExportEnumValue"))) {
			CellData.Value = MakeShared<FLuaIntValue>(EnumProperty->GetUnderlyingProperty()->GetSignedIntPropertyValue(Value));
		}
		else {
			UEnum* EnumDef = EnumProperty->GetEnum();
			FString StringValue = EnumDef->GetAuthoredNameStringByValue(EnumProperty->GetUnderlyingProperty()->GetSignedIntPropertyValue(Value));
			CellData.Value = MakeShared<FLuaStringValue>(StringValue);
		}
	}
	else if (FNumericProperty* NumericProperty = CastField<FNumericProperty>(Property)) {
		if (NumericProperty->HasMetaData("ExportEnumValue")
			|| (NumericProperty->GetOwnerProperty() && NumericProperty->GetOwnerProperty()->HasMetaData("ExportEnumValue"))) {
			CellData.Value = MakeShared<FLuaIntValue>(NumericProperty->GetSignedIntPropertyValue(Value));
		}
		else {
			UEnum* EnumDef = NumericProperty->GetIntPropertyEnum();
			if (EnumDef != NULL) {
				FString StringValue = EnumDef->GetAuthoredNameStringByValue(NumericProperty->GetSignedIntPropertyValue(Value));
				CellData.Value = MakeShared<FLuaStringValue>(StringValue);
			}
			else if (NumericProperty->IsFloatingPoint()) {
				CellData.Value = MakeShared<FLuaNumberValue>(NumericProperty->GetFloatingPointPropertyValue(Value));
			}
			else if (NumericProperty->IsInteger()) {
				CellData.Value = MakeShared<FLuaIntValue>(NumericProperty->GetSignedIntPropertyValue(Value));
			}
		}
	}
	else if (FBoolProperty* BoolProperty = CastField<FBoolProperty>(Property)) {
		CellData.Value = MakeShared<FLuaBoolValue>(BoolProperty->GetPropertyValue(Value));
	}
	else if (FStrProperty* StringProperty = CastField<FStrProperty>(Property)) {
		FString String = StringProperty->GetPropertyValue(Value);
		String.ReplaceInline(TEXT("\r\n"), TEXT("\\n"));
		String.ReplaceInline(TEXT("\n"), TEXT("\\n"));
		CellData.Value = MakeShared<FLuaStringValue>(String);
	}
	else if (FTextProperty* TextProperty = CastField<FTextProperty>(Property)) {
		FString String = TextProperty->GetPropertyValue(Value).ToString();
		String.ReplaceInline(TEXT("\r\n"), TEXT("\\n"));
		String.ReplaceInline(TEXT("\n"), TEXT("\\n"));
		CellData.Value = MakeShared<FLuaStringValue>(String);
	}
	else if (FArrayProperty* ArrayProperty = CastField<FArrayProperty>(Property)) {	
		auto Array = FLuaTable::Create();
		FScriptArrayHelper Helper(ArrayProperty, Value);
		if (FNumericProperty* InnerNumericProperty = CastField<FNumericProperty>(ArrayProperty->Inner)) {
			if(InnerNumericProperty->IsFloatingPoint())
				CellData.ListInnerType = "float";
			else if(InnerNumericProperty->IsInteger())
				CellData.ListInnerType = "int";
		}
		else if (CastField<FBoolProperty>(ArrayProperty->Inner)) {
			CellData.ListInnerType = "bool";
		}
		else if (CastField<FStrProperty>(ArrayProperty->Inner) || CastField<FTextProperty>(ArrayProperty->Inner) || CastField<FNameProperty>(ArrayProperty->Inner)) {
			CellData.ListInnerType = "string";
		}
		for (int32 i = 0, n = Helper.Num(); i < n; ++i) {
			TSharedPtr<FLuaValue> Elem = FLuaTableConverter::UPropertyToLuaValue(ArrayProperty->Inner, Helper.GetRawPtr(i), false, 0, CPF_Transient, ArrayProperty);
			if (Elem.IsValid()) {
				Array->PushValue(Elem);
			}
		}
		CellData.Value = MakeShared<FLuaTableValue>(Array);
	}
	else if (FSetProperty* SetProperty = CastField<FSetProperty>(Property)) {
		auto Set = FLuaTable::Create();
		FScriptSetHelper Helper(SetProperty, Value);
		for (int32 i = 0, n = Helper.Num(); n; ++i) {
			if (Helper.IsValidIndex(i)) {
				TSharedPtr<FLuaValue> Elem = FLuaTableConverter::UPropertyToLuaValue(SetProperty->ElementProp, Helper.GetElementPtr(i), false, 0, CPF_Transient);
				if (Elem.IsValid()) {
					Set->PushValue(Elem);
				}
				--n;
			}
		}
		CellData.Value = MakeShared<FLuaTableValue>(Set);
	}
	else if (FMapProperty* MapProperty = CastField<FMapProperty>(Property)) {
		auto Table = FLuaTable::Create();
		FScriptMapHelper Helper(MapProperty, Value);
		for (int32 i = 0, n = Helper.Num(); n; ++i) {
			if (Helper.IsValidIndex(i)) {
				TSharedPtr<FLuaValue> KeyElement = FLuaTableConverter::UPropertyToLuaValue(MapProperty->KeyProp, Helper.GetKeyPtr(i), false, 0, CPF_Transient);
				TSharedPtr<FLuaValue> ValueElement = FLuaTableConverter::UPropertyToLuaValue(MapProperty->ValueProp, Helper.GetValuePtr(i), false, 0, CPF_Transient);
				if (KeyElement.IsValid() && ValueElement.IsValid()) {
					FString KeyString = KeyElement->AsString();
					if (KeyString.IsEmpty()) {
						MapProperty->KeyProp->ExportTextItem_Direct(KeyString, Helper.GetKeyPtr(i), nullptr, nullptr, 0);
						if (KeyString.IsEmpty()) {
							UE_LOG(LogGameBasicEditor, Error, TEXT("Unable to convert key to string for property %s."), *MapProperty->GetAuthoredName())
								KeyString = FString::Printf(TEXT("Unparsed Key %d"), i);
						}
					}
					Table->Add(KeyString, ValueElement);
				}
				--n;
			}
		}
		CellData.Value = MakeShared<FLuaTableValue>(Table);
	}
	else if (FStructProperty* StructProperty = CastField<FStructProperty>(Property)) {
		UScriptStruct::ICppStructOps* TheCppStructOps = StructProperty->Struct->GetCppStructOps();
		if (CellData.Desc.IsEmpty()) {
			CellData.Desc = StructProperty->Struct->GetName();
		}
		auto Table = FLuaTable::Create();
		if (StructProperty->Struct->GetFName() == NAME_Vector) {
			const FVector& Vector = *(FVector*)Value;
			Table->PushValue(Vector.X);
			Table->PushValue(Vector.Y);
			Table->PushValue(Vector.Z);
			CellData.Value = MakeShared<FLuaTableValue>(Table);
		}
		else if (StructProperty->Struct->GetFName() == NAME_Rotator) {
			const FRotator& Rotator = *(FRotator*)Value;
			Table->PushValue(Rotator.Pitch);
			Table->PushValue(Rotator.Yaw);
			Table->PushValue(Rotator.Roll);
			CellData.Value = MakeShared<FLuaTableValue>(Table);
		}
		else if (StructProperty->Struct->GetFName() == NAME_Quat) {
			const FRotator& Rotator = ((FQuat*)Value)->Rotator();
			Table->PushValue(Rotator.Pitch);
			Table->PushValue(Rotator.Yaw);
			Table->PushValue(Rotator.Roll);
			CellData.Value = MakeShared<FLuaTableValue>(Table);
		}
		else if (auto EName = StructProperty->Struct->GetFName().ToEName()) {
			FLuaTableConverter::UStructToLuaTable(StructProperty->Struct, Value, Table.Get(), false, 0, CPF_Transient);
			CellData.Value = MakeShared<FLuaTableValue>(Table);
		}
		else {
			UStructToGameBasicConfig(StructProperty->Struct, Value, Row, PropertyPath);
			return;
		}
	}
	else if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property)) {
		if (CellData.Desc.IsEmpty()) {
			CellData.Desc = ObjectProperty->PropertyClass->GetName();
		}
		UObject* Object = ObjectProperty->GetObjectPropertyValue(Value);
		if (ObjectProperty->PropertyFlags & CPF_ExportObject) {
			if (Object) {
				TSharedPtr<FLuaTable> Table = FLuaTable::CreateFromObject(Object);
				Table->SetValue(FLuaTableConverter::ClassPathKey, Object->GetClass()->GetClassPathName().ToString());
				CellData.Value = MakeShared<FLuaTableValue>(Table);
			}
			else {
				CellData.Value = MakeShared<FLuaTableValue>();
			}
		}
		else if (Object) {
			if (Object->IsAsset() || Object->IsA<UClass>()) {
				CellData.Value = MakeShared<FLuaStringValue>(Object->GetPathName());
			}
			else {
				UStructToGameBasicConfig(Object->GetClass(), Object, Row, PropertyPath);
				return;
			}
		}
		else {
			CellData.Value = MakeShared<FLuaStringValue>(FString());
		}
	}
	else {
		FString StringValue;
		Property->ExportTextItem_Direct(StringValue, Value, nullptr, nullptr, PPF_None);
		CellData.Value = MakeShared<FLuaStringValue>(StringValue);
	}
	if (!CellData.Value.IsValid()) {
		CellData.Value = MakeShared<FLuaValue>();
	}
	Row.Add(CellData);
}

void FGameBasicConfigStructureConverter::UTransientPropertyToGameBasicConfig(FProperty* Property, const UObject* Obj,
	TArray<FGameBasicConfigCellData>& Row, FString PrePath, FProperty* OuterProperty)
{
	FString Data =TEXT("");
	Property->GetValue_InContainer(Obj, &Data);
	if(Data.IsEmpty() && Row.Num()>0)
		return;
	for(FGameBasicConfigCellData& CellData : Row)
	{
		FString NewData = CellData.Name.Equals(Row[0].Name) ? Data : TEXT("");
		CellData.Value = MakeShared<FLuaStringValue>(NewData);
	}
}

void FGameBasicConfigStructureConverter::UStructToGameBasicConfig(const UStruct* StructDefinition, const void* Struct, TArray<FGameBasicConfigCellData>& Row, FString PrePath /*= ""*/)
{
	for (TFieldIterator<FProperty> It(StructDefinition); It; ++It) {
		if (It->HasAnyPropertyFlags(CPF_Transient))
			continue;
		FProperty* Property = *It;
		const void* ValuePtr = Property->ContainerPtrToValuePtr<uint8>(Struct);
		UPropertyToGameBasicConfig(Property, ValuePtr, Row, PrePath);
	}
}

void FGameBasicConfigStructureConverter::UObjectToGameBasicConfig(const UObject* Obj, TArray<FGameBasicConfigCellData>& Row, FString PrePath /*= ""*/)
{
	for (TFieldIterator<FProperty> It(Obj->GetClass()); It; ++It) {
		if (It->HasAnyPropertyFlags(CPF_Transient))
			continue;
		UPropertyToGameBasicConfig(*It, It->ContainerPtrToValuePtr<uint8>(Obj), Row, PrePath);
	}
}

void FGameBasicConfigStructureConverter::UInstanceToGameBasicConfig(const UObject* Obj,
	TArray<FGameBasicConfigCellData>& Row, FString PrePath)
{
	for (TFieldIterator<FProperty> It(Obj->GetClass()); It; ++It) {
		if (It->HasAnyPropertyFlags(CPF_Transient))
		{
			UTransientPropertyToGameBasicConfig(*It,Obj,Row);
			continue;
		}
		UPropertyToGameBasicConfig(*It, It->ContainerPtrToValuePtr<uint8>(Obj), Row, PrePath);
	}
}
#endif

void FGameBasicConfigStructureConverter::GameBasicConfigToUProperty(const TSharedPtr<FLuaTable>& Header, const TSharedPtr<FLuaTable>& RowData, FProperty* Property, void* OutValue, const UStruct* ContainerStruct, void* Container, FString PrePath /*= ""*/, FProperty* OuterProperty /*= nullptr*/)
{
	FString PropertyPath = FLuaTableConverter::GetPropertyName(Property->GetOwner<UStruct>(), Property);
	if (!PrePath.IsEmpty())
		PropertyPath = FString::Printf(TEXT("%s.%s"), *PrePath, *PropertyPath);
	if (!Header->Contains(PropertyPath)) {
		if (FStructProperty* StructProperty = CastField<FStructProperty>(Property)) {
			GameBasicConfigToUStruct(Header, RowData, StructProperty->Struct, OutValue, ContainerStruct, Container, PropertyPath);
		}
		else if (FObjectProperty* ObjectProperty = CastField<FObjectProperty>(Property)) {
			UClass* PropertyClass = ObjectProperty->PropertyClass;
			GameBasicConfigToUStruct(Header, RowData, PropertyClass, OutValue, ContainerStruct, Container, PropertyPath);
		}
		return;
	}
	int Index = Header->FindRef(PropertyPath)->AsInt();
	FString Key = FString::FromInt(Index);
	if (RowData->Contains(Key)) {
		TSharedPtr<FLuaValue> Value = (*RowData)[Key];
		FLuaTableConverter::LuaValueToUProperty(Value.Get(), Property, OutValue, ContainerStruct, Container);
	}
	
}

void FGameBasicConfigStructureConverter::GameBasicConfigToUStruct(const TSharedPtr<FLuaTable>& Header, const TSharedPtr<FLuaTable>& RowData, const UStruct* StructDefinition, void* OutStruct, const UStruct* ContainerStruct, void* Container, FString PrePath /*= ""*/)
{
	for (TFieldIterator<FProperty> PropIt(StructDefinition); PropIt; ++PropIt) {
		FProperty* Property = *PropIt;
		void* Value = Property->ContainerPtrToValuePtr<uint8>(OutStruct);
		GameBasicConfigToUProperty(Header, RowData, Property, Value, ContainerStruct, Container, PrePath);
	}
}

void FGameBasicConfigStructureConverter::GameBasicConfigToUObject(const TSharedPtr<FLuaTable>& Header, const TSharedPtr<FLuaTable>& RowData, UObject* Obj, FString PrePath /*= ""*/)
{
	for (TFieldIterator<FProperty> It(Obj->GetClass()); It; ++It) {
		GameBasicConfigToUProperty(Header, RowData, *It, It->ContainerPtrToValuePtr<uint8>(Obj), Obj->GetClass(), Obj, PrePath);
	}
}

