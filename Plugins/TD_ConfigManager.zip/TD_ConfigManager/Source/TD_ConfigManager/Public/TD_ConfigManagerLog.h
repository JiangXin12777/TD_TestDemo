#pragma once

#include "CoreMinimal.h"

TD_CONFIGMANAGER_API DECLARE_LOG_CATEGORY_EXTERN(TD_ConfigManagerLog, Log, All);