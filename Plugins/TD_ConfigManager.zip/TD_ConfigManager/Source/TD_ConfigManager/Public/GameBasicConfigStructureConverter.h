#pragma once

#include "LuaTable/LuaTableConverter.h"
#include "LuaTable/LuaValue.h"
#include <string>

struct FGameBasicConfigCellData{
	enum class EExportType {
		None,
		C,
		S,
		CS,
	};
	FString Name;
	FString Desc;
	FString ListInnerType;
	EExportType ExportType;
	TSharedPtr<FLuaValue> Value;
};

namespace FGameBasicConfigStructureConverter {

	// Serialize
#if WITH_EDITOR
	GAMEBASICLUA_API void UPropertyToGameBasicConfig(FProperty* Property, const void* Value, TArray<FGameBasicConfigCellData>& Row, FString PrePath = "", FProperty* OuterProperty = nullptr);
	GAMEBASICLUA_API void UTransientPropertyToGameBasicConfig(FProperty* Property, const UObject* Obj, TArray<FGameBasicConfigCellData>& Row, FString PrePath = "", FProperty* OuterProperty = nullptr);
	GAMEBASICLUA_API void UStructToGameBasicConfig(const UStruct* StructDefinition, const void* Struct, TArray<FGameBasicConfigCellData>& Row, FString PrePath = "");
	GAMEBASICLUA_API void UObjectToGameBasicConfig(const UObject* Obj, TArray<FGameBasicConfigCellData>& Row, FString PrePath = "");
	GAMEBASICLUA_API void UInstanceToGameBasicConfig(const UObject* Obj, TArray<FGameBasicConfigCellData>& Row, FString PrePath = "");
#endif

	// UnSerialize
	GAMEBASICLUA_API void GameBasicConfigToUProperty(const TSharedPtr<FLuaTable>& Header, const TSharedPtr<FLuaTable>& RowData, FProperty* Property, void* OutValue, const UStruct* ContainerStruct, void* Container, FString PrePath = "", FProperty* OuterProperty = nullptr);
	GAMEBASICLUA_API void GameBasicConfigToUStruct(const TSharedPtr<FLuaTable>& Header, const TSharedPtr<FLuaTable>& RowData, const UStruct* StructDefinition, void* OutStruct, const UStruct* ContainerStruct, void* Container, FString PrePath = "");
	GAMEBASICLUA_API void GameBasicConfigToUObject(const TSharedPtr<FLuaTable>& Header, const TSharedPtr<FLuaTable>& RowData, UObject* Obj, FString PrePath = "");
}
