#pragma once

#include "Engine/AssetManager.h"
#include "GameBasicAssetManager.generated.h"

UCLASS(Config = Game)
class TD_CONFIGMANAGER_API UGameBasicAssetManager : public UAssetManager
{
	GENERATED_BODY()
public:
	UGameBasicAssetManager();

	static FString GetDataAssetDir();

	static FString GetPrimaryDataAssetTemplateDir(UObject* DataAssetClass);

	static TArray<FString> GetPrimaryDataAssetInstancePaths(UBlueprint* DataAssetBlueprint);
};