#pragma once

#include "GameBasicConfigStructureBlueprint.generated.h"

USTRUCT(BlueprintType)
struct TD_CONFIGMANAGER_API FGameBasicConfigUrl
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere)
	FString URL;

public:
	bool IsValid() const { return !URL.IsEmpty(); }
};

UCLASS(Blueprintable)
class TD_CONFIGMANAGER_API UGameBasicConfigBase : public UObject
{
	GENERATED_BODY()
public:
};

// 带有标记的Config
UCLASS(Blueprintable)
class TD_CONFIGMANAGER_API UGameBasicConfigRemark : public UGameBasicConfigBase
{
	GENERATED_BODY()

public:

	UPROPERTY(Transient)
	FString Remark;
};

UCLASS(meta = (ShowWorldContextPin, DisableNativeTick))
class TD_CONFIGMANAGER_API UGameBasicConfigStructureBlueprint : public UBlueprint
{
	GENERATED_BODY()
public:
#if WITH_EDITOR
	virtual bool SupportedByDefaultBlueprintFactory() const override;
	virtual bool AlwaysCompileOnLoad() const override;
	virtual bool Rename(const TCHAR* NewName = nullptr, UObject* NewOuter = nullptr, ERenameFlags Flags = REN_None) override;
#endif
	static FString GetConfigStructurePackagePath();
	static FString GetConfigStructureDir();
	static FString GetConfigSourceDir();
	static FString GetConfigDataDir();
	static FString GetExportToolPath();

	FString GetCsvFilePath();
	FString GetLuaFilePath();
	FString GetConfigUrl();
};
