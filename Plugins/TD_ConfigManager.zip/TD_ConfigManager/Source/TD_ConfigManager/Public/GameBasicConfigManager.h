#pragma once


class TD_CONFIGMANAGER_API FGameBasicConfigManager
{
public:
	FGameBasicConfigManager();

	static FGameBasicConfigManager* Get();

	UObject* LoadConfigRow(FString ConfigRowURL);

	TArray<UObject*> LoadConfigTable(FString ConfigURL);

	TMap<int32, UObject*> LoadConfigTableByRemark(FString CsvURL, FString ConfigURL);
};