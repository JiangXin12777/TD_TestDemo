﻿#include "SGameBasicConfigStructureEditor.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Kismet/GameplayStatics.h"
#include "WorldPartition/WorldPartition.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "BlueprintEditorModule.h"
#include "Editor.h"
#include "Selection.h"
#include "Engine/World.h"
#include "EditorSupportDelegates.h"
#include "LevelEditor.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "LuaTable/LuaTable.h"
#include "AssetToolsModule.h"
#include "GameBasicAssetManager.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/ScopedSlowTask.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "GameBasicConfigStructureConverter.h"
#include "csv.hpp"
#include "GameBasicConfigManager.h"
#include "PropertyCustomizationHelpers.h"
#include "HAL/PlatformApplicationMisc.h"
#include <string>
#include <vector>

#define LOCTEXT_NAMESPACE "GameBasic"

void SGameBasicConfigStructureEditor::Construct(const FArguments& InArgs, FBlueprintEditor* InEditor)
{
	auto ToolPath = UGameBasicConfigStructureBlueprint::GetExportToolPath();
	if (!FPaths::FileExists(ToolPath)) {
		FMessageDialog::Open(EAppMsgCategory::Error, EAppMsgType::Ok, LOCTEXT("NoGitlab", "The source table directory could not be found, please run GitCloneKulangsuDataRep.bat in the project directory"));
	}
	FPropertyEditorModule& EditModule = FModuleManager::Get().GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	FDetailsViewArgs DetailsViewArgs;
	//DetailsViewArgs.bAllowMultipleTopLevelObjects = true;
	DetailsViewArgs.bShowObjectLabel = false;
	DetailsViewArgs.bAllowSearch = true;
	DetailsViewArgs.bAllowFavoriteSystem = true;
	DetailsViewArgs.NameAreaSettings = FDetailsViewArgs::ENameAreaSettings::HideNameArea;
	DetailsViewArgs.ViewIdentifier = FName("BlueprintDefaults");
	mDetailsView = EditModule.CreateDetailView(DetailsViewArgs);
	mDetailsView->SetIsPropertyVisibleDelegate(FIsPropertyVisible::CreateLambda([](const FPropertyAndParent& Node) {
		return !Node.Property.HasAnyPropertyFlags(EPropertyFlags::CPF_AdvancedDisplay);
	}));
	mDetailsView->SetIsPropertyReadOnlyDelegate(FIsPropertyReadOnly::CreateLambda([](const FPropertyAndParent& Node) {
		return Node.Property.HasAnyPropertyFlags(EPropertyFlags::CPF_DisableEditOnInstance);
	}));
	mDetailsView->OnFinishedChangingProperties().AddLambda([this](const FPropertyChangedEvent&) {
		mBtSave->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("FlatButton.Danger"));
	});
	mEditor = InEditor;
	mEditor->GetBlueprintObj()->OnCompiled().AddSP(this, &SGameBasicConfigStructureEditor::OnBlueprintCompiled);

	Load();

	ChildSlot
		.VAlign(VAlign_Fill)
		.HAlign(HAlign_Fill)
		[
		SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.Padding(10)	
			.AutoHeight()
			[
				SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.Padding(5)
					.HAlign(HAlign_Left)
					.VAlign(VAlign_Center)
					[
						SNew(STextBlock)
						.Text_Lambda([this]() { 
							return FText::FromString("[" + GetEditorBlueprint()->GetConfigUrl() + "]");
						})
					]
					+ SHorizontalBox::Slot()
					.Padding(5)
					.HAlign(HAlign_Right)
					.AutoWidth()
					[
						SNew(SButton)
							.Text(LOCTEXT("Csv", "Csv"))
							.ContentPadding(FMargin(6, 2))
							.OnClicked_Lambda([this]() {
								this->BrowseToCsvFile();
								return FReply::Handled();
							})
					]
					+ SHorizontalBox::Slot()
					.Padding(5)
					.HAlign(HAlign_Right)
					.AutoWidth()
					[
						SNew(SButton)
							.Text(LOCTEXT("Lua", "Lua"))
							.ContentPadding(FMargin(6, 2))
							.OnClicked_Lambda([this]() {
								this->BrowseToLuaFile();
								return FReply::Handled();
							})
					]
					+SHorizontalBox::Slot()
					.Padding(5)
					.HAlign(HAlign_Right)
					.AutoWidth()
					[
						SNew(SButton)
							.Text(LOCTEXT("Create", "+"))
							.ButtonStyle(FAppStyle::Get(), "FlatButton.Success")
							.ContentPadding(FMargin(6, 2))
							.OnClicked(this, &SGameBasicConfigStructureEditor::OnBtCreateClicked)
					]
					+ SHorizontalBox::Slot()
					.Padding(5)
					.AutoWidth()
					.HAlign(HAlign_Right)
					[
						SAssignNew(mBtSave, SButton)
							.Text(LOCTEXT("Save", "Save"))
							.ButtonStyle(FAppStyle::Get(), "FlatButton.Success")
							.ContentPadding(FMargin(6, 2))
							.OnClicked(this, &SGameBasicConfigStructureEditor::OnBtSaveAllClicked)
					]
					+ SHorizontalBox::Slot()
					.Padding(5)
					.AutoWidth()
					.HAlign(HAlign_Right)
					[
						SNew( SButton)
							.Text(LOCTEXT("Refresh", "Refresh"))
							.ButtonStyle(FAppStyle::Get(), "FlatButton.Success")
							.ContentPadding(FMargin(6, 2))
							.OnClicked(this, &SGameBasicConfigStructureEditor::OnBtRefreshClicked)
					]

			]
			+ SVerticalBox::Slot()
			.VAlign(VAlign_Fill)
			[
				SNew(SSplitter)
					.Orientation(Orient_Vertical)
					+ SSplitter::Slot()
					.Value(0.3)
					[
						SAssignNew(mViewBox,SBox)
					]
					+ SSplitter::Slot()
					.Value(0.7)
					[
						mDetailsView.ToSharedRef()
					]
			]
		];
	mViewBox->SetContent(
		SAssignNew(mInstanceView, SListView<UObject*>)
		.ListItemsSource(&mInstanceList)
		.OnGenerateRow_Raw(this, &SGameBasicConfigStructureEditor::OnGenerateRow)
		.OnSelectionChanged_Raw(this, &SGameBasicConfigStructureEditor::OnSelectionChanged)
		.OnItemToString_Debug(this, &SGameBasicConfigStructureEditor::OnItemDebug)
	);
}

UGameBasicConfigStructureBlueprint* SGameBasicConfigStructureEditor::GetEditorBlueprint()
{
	return Cast<UGameBasicConfigStructureBlueprint>(mEditor->GetBlueprintObj());
}

void SGameBasicConfigStructureEditor::OnBlueprintCompiled(UBlueprint* InBlueprint)
{
	mDetailsView->SetObject(nullptr);
	Save();
	mViewBox->SetContent(
		SAssignNew(mInstanceView, SListView<UObject*>)
		.ListItemsSource(&mInstanceList)
		.OnGenerateRow_Raw(this, &SGameBasicConfigStructureEditor::OnGenerateRow)
		.OnSelectionChanged_Raw(this, &SGameBasicConfigStructureEditor::OnSelectionChanged)
		.OnItemToString_Debug(this, &SGameBasicConfigStructureEditor::OnItemDebug)
	);
}

FString SGameBasicConfigStructureEditor::OnItemDebug(UObject* Instance)
{
	if (!Instance->IsValidLowLevel())
		return "";
	return Instance->GetName();
}

void SGameBasicConfigStructureEditor::Load()
{
	mInstanceList = FGameBasicConfigManager::Get()->LoadConfigTable(GetEditorBlueprint()->GetConfigUrl());
	TrySortInstanceList();
	if (mInstanceView) {
		mInstanceView->RebuildList();
	}
}

using namespace csv2;
using namespace std;

void SGameBasicConfigStructureEditor::Save(bool bShowNotify)
{
	FString CsvPath = GetEditorBlueprint()->GetCsvFilePath();
	TMap<int32, UObject*> RemarkList = FGameBasicConfigManager::Get()->LoadConfigTableByRemark(CsvPath, GetEditorBlueprint()->GetConfigUrl());
	
	std::ofstream Stream(TCHAR_TO_UTF8(*CsvPath), std::ios::out);
	if (!Stream.is_open()) {
		if (bShowNotify) {
			FNotificationInfo NotificationInfo(FText::FromString("SaveError"));
			NotificationInfo.Text = FText::Format(LOCTEXT("SaveError", "Save Error: Can`t write file {0}"), FText::FromString(CsvPath));
			NotificationInfo.bFireAndForget = true;
			NotificationInfo.ExpireDuration = 3.0f;
			NotificationInfo.bUseThrobber = true;
			FSlateNotificationManager::Get().AddNotification(NotificationInfo);
		}
		return;
	}
	uint8_t szUTF_8BOM[4] = { 0xEF, 0xBB, 0xBF, 0 };
	Stream << szUTF_8BOM;
	Writer<delimiter<','>> Writer(Stream);
	std::vector<std::vector<std::string>> CsvTable;
	TArray<FGameBasicConfigCellData> HeaderRow;
	FGameBasicConfigStructureConverter::UObjectToGameBasicConfig(GetEditorBlueprint()->GeneratedClass->GetDefaultObject(), HeaderRow);
	CsvTable.resize(4);
	std::vector<std::string>& NameRow = CsvTable[0];
	std::vector<std::string>& ElementTypeRow = CsvTable[1];
	std::vector<std::string>& ExportTypeRow = CsvTable[2];
	std::vector<std::string>& DescRow = CsvTable[3];

	auto MakeCsvString = [](FString Str) {
		Str.ReplaceInline(TEXT("\""), TEXT("\"\""));
		Str = "\"" + Str + "\"";
		return std::string(TCHAR_TO_UTF8(*Str));
		};

	bool flag = true;

	for (auto Cell : HeaderRow) {
		NameRow.push_back(TCHAR_TO_UTF8(*Cell.Name));
		FString ElementTypeString;
		if (Cell.ListInnerType.IsEmpty()) {
			switch (Cell.Value->GetType())
			{
			case ELuaValueType::Nil:
				continue;
				break;
			case ELuaValueType::Bool:
				ElementTypeString = "bool";
				break;
			case ELuaValueType::Int:
				ElementTypeString = "int";
				break;
			case ELuaValueType::Number:
				ElementTypeString = "float";
				break;
			case ELuaValueType::String:
				ElementTypeString = "string";
				break;
			case ELuaValueType::Table:
				ElementTypeString = "lua";
				break;
			}
		}
		else {
			ElementTypeString = FString::Printf(TEXT("list<%s>"), *Cell.ListInnerType);
		}
		ElementTypeRow.push_back(MakeCsvString(ElementTypeString));

		FString ExportTypeString;
		switch (Cell.ExportType)
		{
		case FGameBasicConfigCellData::EExportType::C:
			ExportTypeString = "C";
			break;
		case FGameBasicConfigCellData::EExportType::S:
			ExportTypeString = "S";
			break;
		case FGameBasicConfigCellData::EExportType::CS:
			ExportTypeString = "CS";
			break;
		}
		ExportTypeRow.push_back(MakeCsvString(ExportTypeString));
		if (flag) {
			DescRow.push_back(MakeCsvString("#" + Cell.Desc));
			flag = false;
		}
		else {
			DescRow.push_back(MakeCsvString(Cell.Desc));
		}
	}
	TrySortInstanceList();
	TArray<int32> Keys;
	RemarkList.GetKeys(Keys);
	if(DescRow.size()>0&&Keys.Num()>0)
	{
		RemarkList.Remove(Keys[0]);
	}
	for(auto Pair:RemarkList)
	{
		mInstanceList.Insert(Pair.Value,Pair.Key - CsvTable.size());
	}
	
	for (int i = 0; i < mInstanceList.Num(); i++) {
		auto Instance = mInstanceList[i];
		std::vector<std::string> DataRow;
		TArray<FGameBasicConfigCellData> Row;
		FGameBasicConfigStructureConverter::UInstanceToGameBasicConfig(Instance, Row);
		for (auto Cell : Row) {
			FString Str = Cell.Value->ToString();
			std::string CsvStr;
			if (Cell.Value->GetType() == ELuaValueType::String)
				CsvStr = MakeCsvString(Cell.Value->AsString());
			else if (Cell.Value->GetType() == ELuaValueType::Table) {
				if (!Cell.ListInnerType.IsEmpty()) {
					FString Children;
					auto Table = Cell.Value->AsTable();
					for (int j = 0; j < Table->Num(); j++) {
						if (j != 0) {
							Children = Children +"|";
						}
						auto ChildValue = (*Table)[j + 1];
						if (ChildValue->GetType() == ELuaValueType::String)
							Children += ChildValue->AsString();
						else
							Children += ChildValue->ToString();
					}
					CsvStr = MakeCsvString(Children);
				}
				else {
					CsvStr = MakeCsvString(Str);
				}
			}
			else
				CsvStr = TCHAR_TO_UTF8(*Str);
			DataRow.push_back(CsvStr);
		}
		CsvTable.push_back(DataRow);
	}
	
	for(auto Pair:RemarkList)
		mInstanceList.Remove(Pair.Value);
	
	Writer.write_rows(CsvTable);
	Stream.close();

	FString Message = RunCsvExportTool();
	
	FGameBasicConfigManager::Get()->LoadConfigTable(GetEditorBlueprint()->GetConfigUrl());

	if (bShowNotify) {
		FNotificationInfo NotificationInfo(FText::FromString("Save"));
		NotificationInfo.Text = FText::Format(LOCTEXT("SaveSuccessfully", "Save successfully! \nPath:{0} \nMessage:{1}"), FText::FromString(CsvPath), FText::FromString(Message));
		NotificationInfo.bFireAndForget = true;
		NotificationInfo.ExpireDuration = 5.0f;
		NotificationInfo.bUseThrobber = true;
		NotificationInfo.WidthOverride = 600;
		FNotificationButtonInfo BtYesInfo = FNotificationButtonInfo(
			LOCTEXT("BrowseCsvFile", "Browse csv file"),
			LOCTEXT("BrowseCsvFile", "Browse csv file"),
			FSimpleDelegate::CreateSP(this,&SGameBasicConfigStructureEditor::BrowseToCsvFile),
			SNotificationItem::ECompletionState::CS_None
		);
		FNotificationButtonInfo BtNoInfo = FNotificationButtonInfo(
			LOCTEXT("BrowseLuaFile", "Browse lua file"),
			LOCTEXT("BrowseLuaFile", "Browse lua file"),
			FSimpleDelegate::CreateSP(this, &SGameBasicConfigStructureEditor::BrowseToLuaFile),
			SNotificationItem::ECompletionState::CS_None
		);
		NotificationInfo.ButtonDetails.Add(BtYesInfo);
		NotificationInfo.ButtonDetails.Add(BtNoInfo);
		FSlateNotificationManager::Get().AddNotification(NotificationInfo);
	}

	mBtSave->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("FlatButton.Success"));
}

void SGameBasicConfigStructureEditor::BrowseToCsvFile()
{
	FString Path = GetEditorBlueprint()->GetCsvFilePath();
	if (FPaths::FileExists(*Path)) {
		FPlatformProcess::ExploreFolder(*Path);
	}
	else {
		FNotificationInfo NotificationInfo(FText::FromString("FileNotExisted"));
		NotificationInfo.Text = FText::Format(LOCTEXT("FileNotExisted", "File is not exist: {0}"), FText::FromString(Path));
		NotificationInfo.bFireAndForget = true;
		NotificationInfo.ExpireDuration = 3.0f;
		NotificationInfo.bUseThrobber = true;
		FSlateNotificationManager::Get().AddNotification(NotificationInfo);
	}
}

void SGameBasicConfigStructureEditor::BrowseToLuaFile()
{
	FString Path = GetEditorBlueprint()->GetLuaFilePath();
	if (FPaths::FileExists(*Path)) {
		FPlatformProcess::ExploreFolder(*Path);
	}
	else {
		FNotificationInfo NotificationInfo(FText::FromString("FileNotExisted"));
		NotificationInfo.Text = FText::Format(LOCTEXT("FileNotExisted", "File is not exist: {0}"), FText::FromString(Path));
		NotificationInfo.bFireAndForget = true;
		NotificationInfo.ExpireDuration = 3.0f;
		NotificationInfo.bUseThrobber = true;
		FSlateNotificationManager::Get().AddNotification(NotificationInfo);
	}
}

void SGameBasicConfigStructureEditor::CreateNewRow()
{
	auto NewInstance = NewObject<UObject>(GetTransientPackage(), GetEditorBlueprint()->GeneratedClass);
	mInstanceList.Add(NewInstance);
	mInstanceView->RequestListRefresh();
	mBtSave->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("FlatButton.Danger"));
}

void SGameBasicConfigStructureEditor::RemoveRows(TArray<UObject*> Instances)
{
	for (auto Instance : Instances) {
		mInstanceList.Remove(Instance);
	}
	mInstanceView->RequestListRefresh();
	mBtSave->SetButtonStyle(&FAppStyle::Get().GetWidgetStyle<FButtonStyle>("FlatButton.Danger"));
}

void SGameBasicConfigStructureEditor::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	mEditor->GetInspector()->Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
}

void SGameBasicConfigStructureEditor::AddReferencedObjects(FReferenceCollector& Collector)
{
	Collector.AddReferencedObjects(mInstanceList);
}

TSharedRef<ITableRow> SGameBasicConfigStructureEditor::OnGenerateRow(UObject* Instance, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(STableRow<UObject*>, OwnerTable)
		.Padding(FMargin(8.f, 2.f, 12.f, 2.f))
		.Content()
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.VAlign(VAlign_Center)
			[
				SNew(STextBlock)
					.Text_Lambda([this, Instance]() {
						return FText::FromString(GetRowKeyName(Instance));
					})
			]
			+ SHorizontalBox::Slot()
			.HAlign(HAlign_Right)
			.AutoWidth()
			[
				PropertyCustomizationHelpers::MakeBrowseButton(FSimpleDelegate::CreateLambda([this, Instance]() {
					FString Url = FString::Printf(TEXT("%s.%s"), *GetEditorBlueprint()->GetConfigUrl(), *GetRowKeyName(Instance));
					FPlatformApplicationMisc::ClipboardCopy(*Url);
					FNotificationInfo NotificationInfo(FText::FromString("Copy successfully"));
					NotificationInfo.Text = LOCTEXT("CopySuccessfully", "Copy successfully");
					NotificationInfo.bFireAndForget = true;
					NotificationInfo.ExpireDuration = 2.0f;
					NotificationInfo.bUseThrobber = true;
					FSlateNotificationManager::Get().AddNotification(NotificationInfo);
				}),LOCTEXT("CopyUrl","Copy Url"))
			]
			+ SHorizontalBox::Slot()
			.HAlign(HAlign_Right)
				.AutoWidth()
			[
				PropertyCustomizationHelpers::MakeDeleteButton(FSimpleDelegate::CreateLambda([this, Instance]() {
					RemoveRows({ Instance });
				}))
			]
		];
}

void SGameBasicConfigStructureEditor::OnSelectionChanged(UObject* Instance, ESelectInfo::Type Info)
{
	TArray<UObject*> Objects;
	for (auto Item : mInstanceView->GetSelectedItems()) {
		Objects.Add(Item);
	}
	mDetailsView->SetObjects(Objects, true);
}

FReply SGameBasicConfigStructureEditor::OnBtCreateClicked()
{
	CreateNewRow();
	return FReply::Handled();
}

FReply SGameBasicConfigStructureEditor::OnBtSaveAllClicked()
{
	Save(true);
	return FReply::Handled();
}

FReply SGameBasicConfigStructureEditor::OnBtRefreshClicked()
{
	RunCsvExportTool();
	Load();
	return FReply::Handled();
}

FString SGameBasicConfigStructureEditor::RunCsvExportTool()
{
	FScopedSlowTask RootTask(1, (LOCTEXT("Exporting", "Exporting...")));
	RootTask.MakeDialog();
	FString ToolPath = UGameBasicConfigStructureBlueprint::GetExportToolPath();
	FString InputDir = GetEditorBlueprint()->GetCsvFilePath();
	FString OutputDir = UGameBasicConfigStructureBlueprint::GetConfigDataDir();
	FString Params = FString::Printf(TEXT("3 %s %s"),  *InputDir, *OutputDir);
	void* ReadPipe = nullptr, * WritePipe = nullptr;
	//FPlatformProcess::CreatePipe(ReadPipe, WritePipe);
	auto ProcHandle = FPlatformProcess::CreateProc(*ToolPath, *Params, false, true, true, nullptr, 0, nullptr, WritePipe);
	FPlatformProcess::WaitForProc(ProcHandle);
	//FString Message = FPlatformProcess::ReadPipe(ReadPipe);
	//FPlatformProcess::ClosePipe(ReadPipe, WritePipe);
	//FPlatformProcess::CloseProc(ProcHandle);
	RootTask.EnterProgressFrame(1, FText::FromString("Exporting..."));
	return "";
}

FString SGameBasicConfigStructureEditor::GetRowKeyName(UObject* Row)
{
	UClass* Class = Row->GetClass();
	for (TFieldIterator<FProperty> PropertyIterator(Class); PropertyIterator; ++PropertyIterator)
	{
		FProperty* Prop = *PropertyIterator;
		if (Prop->GetName() != "UberGraphFrame") {
			TSharedPtr<FLuaValue> Value = FLuaTableConverter::UPropertyToLuaValue(Prop, Prop->ContainerPtrToValuePtr<void*>(Row), false);
			if (Value->IsString())
				return Value->AsString();
			return Value->ToString();
		}	
	}
	return FString("InvaildPrimaryKey");
}

void SGameBasicConfigStructureEditor::TrySortInstanceList()
{
	UClass* Class = GetEditorBlueprint()->GeneratedClass;
	FNumericProperty* NumberProp = nullptr;
	for (TFieldIterator<FProperty> PropertyIterator(Class); PropertyIterator; ++PropertyIterator)
	{
		FProperty* Prop = *PropertyIterator;
		if (Prop->GetName() != "UberGraphFrame") {
			NumberProp = CastField<FNumericProperty>(Prop);
			break;
		}
	}
	if (NumberProp) {
		mInstanceList.Sort([NumberProp](const UObject& A, const UObject& B) {
			FString AStr = NumberProp->GetNumericPropertyValueToString_InContainer(&A);
			FString BStr = NumberProp->GetNumericPropertyValueToString_InContainer(&B);
			return FCString::Atod(*AStr) < FCString::Atod(*BStr);
		});
	}
}

#undef LOCTEXT_NAMESPACE