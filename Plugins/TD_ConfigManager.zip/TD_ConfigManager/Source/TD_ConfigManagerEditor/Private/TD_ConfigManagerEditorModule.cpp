﻿#include "TD_ConfigManagerEditorModule.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "EditorModeRegistry.h"
#include "BlueprintEditorTabs.h"
#include "Toolkits/AssetEditorToolkitMenuContext.h"
#include "BlueprintEditor.h"
#include "ISettingsModule.h"

#define LOCTEXT_NAMESPACE "TD_ConfigManagerEditorModule"

void FTD_ConfigManagerEditorModule::StartupModule()
{
	FCoreUObjectDelegates::PostLoadMapWithWorld.AddLambda([](UWorld* World) {
		if (World && World->GetPackage()->GetPIEInstanceID() == INDEX_NONE) {
			World->GetPackage()->SetPIEInstanceID(0);
		}
	});

	UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("AssetEditor.BlueprintEditor.ToolBar");
	FToolMenuSection& ToolBarSection = ToolbarMenu->AddSection("TabulatingTool");
	ToolBarSection.AddDynamicEntry("TabulatingTool", FNewToolMenuSectionDelegate::CreateLambda([this](FToolMenuSection& InSection) {
		if (auto EditorContext = InSection.FindContext<UAssetEditorToolkitMenuContext>()) {
			FBlueprintEditor* Editor = (FBlueprintEditor*)EditorContext->Toolkit.Pin().Get();
			TSharedPtr<FTabManager> TabMgr = Editor->GetTabManager();
			if (!TabMgr.IsValid())
				return;
			if (TabMgr->FindExistingLiveTab(FName("Tabulation")))
				return;
			if (Editor->GetBlueprintObj() && Editor->GetBlueprintObj()->IsA<UGameBasicConfigStructureBlueprint>()) {
				if (TabMgr && TabMgr->FindExistingLiveTab(FBlueprintEditorTabs::DetailsID)) {
					TabMgr->InsertNewDocumentTab(FBlueprintEditorTabs::DetailsID, FName("Tabulation"), FTabManager::FLiveTabSearch(),
						SNew(SDockTab)
						.TabRole(ETabRole::DocumentTab)
						.ContentPadding(FMargin(3.0f))
						.Label(LOCTEXT("Tabulation", "Tabulation"))
						[
							SNew(SGameBasicConfigStructureEditor, Editor)
						]
					);
					TabMgr->TryInvokeTab(FBlueprintEditorTabs::DetailsID);
				}
			}
		}
	}));

	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	AssetTools.RegisterAdvancedAssetCategory("MiGu", LOCTEXT("MiGu", "MiGu"));
	mConfigStructureAssetActions = MakeShared<FGameBasicConfigStructureBlueprintAssetActions>();
	AssetTools.RegisterAssetTypeActions(mConfigStructureAssetActions.ToSharedRef());

	FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomPropertyTypeLayout(FGameBasicConfigUrl::StaticStruct()->GetFName(), FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FPropertyTypeCustomization_GameBasicConfigUrl::MakeInstance));
}

void FTD_ConfigManagerEditorModule::ShutdownModule()
{
	if (FModuleManager::Get().IsModuleLoaded("AssetTools")) {
		IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
		AssetTools.UnregisterAssetTypeActions(mConfigStructureAssetActions.ToSharedRef());
		mConfigStructureAssetActions.Reset();
	}
}


#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FTD_ConfigManagerEditorModule, TD_ConfigManagerEditorModule)