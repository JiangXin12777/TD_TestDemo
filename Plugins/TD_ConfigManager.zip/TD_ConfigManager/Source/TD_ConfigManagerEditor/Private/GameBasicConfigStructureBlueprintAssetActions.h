#pragma once

#include "AssetTypeActions/AssetTypeActions_Blueprint.h"
#include "GameBasicConfigStructureBlueprint.h"
#include "IPropertyTypeCustomization.h"
#include "GameBasicConfigStructureBlueprintAssetActions.generated.h"

class TD_CONFIGMANAGEREDITOR_API FGameBasicConfigStructureBlueprintAssetActions : public FAssetTypeActions_Blueprint
{
public:
	virtual FText GetName() const override;
	virtual UClass* GetSupportedClass() const override;
	virtual FColor GetTypeColor() const override;
	virtual uint32 GetCategories() override;
	virtual void OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<IToolkitHost> EditWithinLevelEditor = TSharedPtr<IToolkitHost>()) override;
	virtual bool HasActions(const TArray<UObject*>& InObjects) const override;
	virtual void GetActions(const TArray<UObject*>& InObjects, struct FToolMenuSection& Section) override;
	virtual bool CanLocalize() const override { return false; };
	bool CanDuplicate(const FAssetData& InAsset, FText* OutErrorMsg) const override { return false; }
};

UCLASS()
class TD_CONFIGMANAGEREDITOR_API UGameBasicConfigStructureBlueprintFactory : public UFactory
{
	GENERATED_UCLASS_BODY()
	virtual UObject* FactoryCreateNew(UClass* Class, UObject* InParent, FName Name, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn) override;
	virtual bool CanCreateNew() const override { return true; }
protected:
	UPROPERTY(EditAnywhere, Category = WidgetBlueprintFactory, meta = (AllowAbstract = ""))
	TSubclassOf<class UObject> ParentClass;
};

class FPropertyTypeCustomization_GameBasicConfigUrl
	: public IPropertyTypeCustomization
{
public:
	struct FConfigUrlField {
		FString Name;
		FConfigUrlField* Parent;
		TArray<TSharedPtr<FConfigUrlField>> Children;
	};

	static TSharedRef<IPropertyTypeCustomization> MakeInstance();

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& InHeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override {};
	TSharedRef<SWidget> OnGetUrlComboBox();

	TSharedRef<ITableRow> OnGenerateRow(TSharedPtr<FConfigUrlField> InField, const TSharedRef<STableViewBase>& OwnerTable);
	void OnGetChildren(TSharedPtr<FConfigUrlField> InField, TArray< TSharedPtr<FConfigUrlField> >& OutChildren);
	void OnSelectionChanged(TSharedPtr<FConfigUrlField> InField, ESelectInfo::Type SelectInfo);
	bool IsSelectableOrNavigable(TSharedPtr<FConfigUrlField> InField) const;
private:
	FGameBasicConfigUrl* URL;
	TArray<TSharedPtr<FConfigUrlField>> ConfigUrlTree;
	TSharedPtr<STreeView<TSharedPtr<FConfigUrlField>>> ConfigUrlTreeView;
	TSharedPtr<IPropertyHandle> mPropertyHandle;
	FString UrlPrefix;
};