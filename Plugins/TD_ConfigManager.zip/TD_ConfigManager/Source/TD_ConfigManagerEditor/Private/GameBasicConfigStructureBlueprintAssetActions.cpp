﻿#include "GameBasicConfigStructureBlueprintAssetActions.h"
#include "BlueprintEditorModule.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "SGameBasicConfigStructureEditor.h"
#include "DetailLayoutBuilder.h"
#include "DetailCategoryBuilder.h"
#include "DetailWidgetRow.h"
#include "IDetailChildrenBuilder.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "LuaTable/LuaTable.h"

#define LOCTEXT_NAMESPACE "GameBasicEditor"

FText FGameBasicConfigStructureBlueprintAssetActions::GetName() const
{
	return LOCTEXT("GameBasicConfigStructure", "Game Basic Config Structure");
}

UClass* FGameBasicConfigStructureBlueprintAssetActions::GetSupportedClass() const
{
	return UGameBasicConfigStructureBlueprint::StaticClass();
}

FColor FGameBasicConfigStructureBlueprintAssetActions::GetTypeColor() const
{
	return FColor(0, 100, 200);
}

uint32 FGameBasicConfigStructureBlueprintAssetActions::GetCategories()
{
	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	return AssetTools.FindAdvancedAssetCategory("MiGu");
}

void FGameBasicConfigStructureBlueprintAssetActions::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<IToolkitHost> EditWithinLevelEditor /*= TSharedPtr<IToolkitHost>()*/)
{
	for (UObject* Object : InObjects)
	{
		if (UBlueprint* Blueprint = Cast<UBlueprint>(Object))
		{
			bool bLetOpen = true;
			if (!Blueprint->SkeletonGeneratedClass || !Blueprint->GeneratedClass)
			{
				bLetOpen = EAppReturnType::Yes == FMessageDialog::Open(EAppMsgType::YesNo, LOCTEXT("FailedToLoadBlueprintWithContinue", "Blueprint could not be loaded because it derives from an invalid class.  Check to make sure the parent class for this blueprint hasn't been removed! Do you want to continue (it can crash the editor)?"));
			}
			if (bLetOpen)
			{
				FBlueprintEditorModule& BlueprintEditorModule = FModuleManager::LoadModuleChecked<FBlueprintEditorModule>("Kismet");
				TSharedRef< IBlueprintEditor > NewKismetEditor = BlueprintEditorModule.CreateBlueprintEditor(EToolkitMode::Standalone, nullptr, Blueprint);
			}
		}
		else
		{
			FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("FailedToLoadBlueprint", "Blueprint could not be loaded because it derives from an invalid class.  Check to make sure the parent class for this blueprint hasn't been removed!"));
		}
	}
}

bool FGameBasicConfigStructureBlueprintAssetActions::HasActions(const TArray<UObject*>& InObjects) const
{
	return true;
}

void FGameBasicConfigStructureBlueprintAssetActions::GetActions(const TArray<UObject*>& InObjects, struct FToolMenuSection& Section)
{

}

UGameBasicConfigStructureBlueprintFactory::UGameBasicConfigStructureBlueprintFactory(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer) {
	SupportedClass = UGameBasicConfigStructureBlueprint::StaticClass();
	bCreateNew = true;
	bEditAfterNew = true;
	ParentClass = UGameBasicConfigBase::StaticClass();
}

UObject* UGameBasicConfigStructureBlueprintFactory::FactoryCreateNew(UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	check(InClass->IsChildOf(UBlueprint::StaticClass()));
	if ((ParentClass == NULL))
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("ClassName"), (ParentClass != NULL) ? FText::FromString(ParentClass->GetName()) : NSLOCTEXT("UnrealEd", "Null", "(null)"));
		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(NSLOCTEXT("UnrealEd", "CannotCreateBlueprintFromClass", "Cannot create a blueprint based on the class '{0}'."), Args));
		return NULL;
	}
	if (!InParent->GetPathName().Contains(UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath())) {
		FMessageDialog::Open(EAppMsgType::Ok, FText::Format(LOCTEXT("DirError", "Can only create configuration structures in '{0}/'"), FText::FromString(UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath())));
		FContentBrowserModule& ContentBrowserModule = FModuleManager::Get().LoadModuleChecked<FContentBrowserModule>("ContentBrowser");
		ContentBrowserModule.Get().SyncBrowserToFolders({ UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath() }, true);
		return NULL;
	}
	UGameBasicConfigStructureBlueprint* NewBP = CastChecked<UGameBasicConfigStructureBlueprint>(FKismetEditorUtilities::CreateBlueprint(ParentClass, InParent, InName, BPTYPE_Normal, UGameBasicConfigStructureBlueprint::StaticClass(), UBlueprintGeneratedClass::StaticClass(), NAME_None));
	return NewBP;
}

#undef LOCTEXT_NAMESPACE

TSharedRef<IPropertyTypeCustomization> FPropertyTypeCustomization_GameBasicConfigUrl::MakeInstance()
{
	return MakeShared<FPropertyTypeCustomization_GameBasicConfigUrl>();
}

void FPropertyTypeCustomization_GameBasicConfigUrl::CustomizeHeader(TSharedRef<IPropertyHandle> InPropertyHandle, FDetailWidgetRow& InHeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	void* Ptr = nullptr;
	InPropertyHandle->GetValueData(Ptr);
	mPropertyHandle = InPropertyHandle;
	URL = (FGameBasicConfigUrl*)Ptr;
	UrlPrefix = InPropertyHandle->GetMetaData("ConfigUrlPrefix");
	InHeaderRow
		.ShouldAutoExpand()
		.NameContent()
		[
			InPropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SNew(SComboButton)
			.OnGetMenuContent(this, &FPropertyTypeCustomization_GameBasicConfigUrl::OnGetUrlComboBox)
			.ContentPadding(FMargin(2.0f, 2.0f))
			.ButtonContent()
			[
				SNew(STextBlock)
				.Text_Lambda([this]() { return FText::FromString(URL->URL); })
			]
		];
}

TSharedRef<SWidget> FPropertyTypeCustomization_GameBasicConfigUrl::OnGetUrlComboBox()
{
	ConfigUrlTree.Reset();
	TSharedPtr<FConfigUrlField> NullField = MakeShared<FConfigUrlField>();
	NullField->Name = "None";
	ConfigUrlTree.Add(NullField);
	TArray<FAssetData> AssetDataList;
	IAssetRegistry& AssetRegistry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
	AssetRegistry.GetAssetsByPath(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), AssetDataList, true);
	for (auto AssetData : AssetDataList) {
		if (AssetData.GetClass() == UGameBasicConfigStructureBlueprint::StaticClass()) {
			FString ConfigUrl = AssetData.PackageName.ToString()
				.Replace(*UGameBasicConfigStructureBlueprint::GetConfigStructurePackagePath(), TEXT(""))
				.TrimChar(TCHAR('/'))
				.Replace(TEXT("/"), TEXT("."))
				.Replace(TEXT("DC_"),TEXT(""));
			if (!UrlPrefix.IsEmpty() && !ConfigUrl.StartsWith(UrlPrefix)) {
				continue;
			}
			FString LuaPath = UGameBasicConfigStructureBlueprint::GetConfigDataDir() / AssetData.AssetName.ToString() + ".lua";
			auto ConfigData = FLuaTable::CreateFromFile(LuaPath);
			TSharedPtr<FLuaTable> Header = ConfigData->FindOrReturn("Data", ELuaValueType::Table)->AsTable();
			for (auto Item : *Header) {
				FString FullUrl = ConfigUrl + "." + Item.Key;
				TArray<FString> Fields;
				FullUrl.ParseIntoArray(Fields, TEXT("."),true);
				TArray<TSharedPtr<FConfigUrlField>>* Level = &ConfigUrlTree;
				FConfigUrlField* Parent = nullptr;
				for (auto& Field : Fields) {
					bool bFound = false;
					for (auto L : *Level) {
						if (L->Name == Field) {
							Level = &L->Children;
							Parent = L.Get();
							bFound = true;
							break;
						}
					}
					if (!bFound) {
						TSharedPtr<FConfigUrlField> NewField = MakeShared<FConfigUrlField>();
						NewField->Name = Field;
						NewField->Parent = Parent;
						Level->Add(NewField);
						Parent = NewField.Get();
						Level = &NewField->Children;
					}
				}
			}
		}
	}

	return SNew(SBox)
		.WidthOverride(350)
		.HeightOverride(300)
		[
			SNew(SScrollBox)
			+ SScrollBox::Slot()
			[
				SNew(SBorder)
					.Padding(2.0f)
					.BorderImage(FAppStyle::GetBrush("SCSEditor.TreePanel"))
				[
					SAssignNew(ConfigUrlTreeView, STreeView<TSharedPtr<FConfigUrlField>>)
						.TreeItemsSource(&ConfigUrlTree)
						.SelectionMode(ESelectionMode::Single)
						.OnGenerateRow(this, &FPropertyTypeCustomization_GameBasicConfigUrl::OnGenerateRow)
						.OnGetChildren(this, &FPropertyTypeCustomization_GameBasicConfigUrl::OnGetChildren)
						.OnSelectionChanged(this, &FPropertyTypeCustomization_GameBasicConfigUrl::OnSelectionChanged)
						.OnIsSelectableOrNavigable(this, &FPropertyTypeCustomization_GameBasicConfigUrl::IsSelectableOrNavigable)
				]
			]
		]
		;
}

TSharedRef<ITableRow> FPropertyTypeCustomization_GameBasicConfigUrl::OnGenerateRow(TSharedPtr<FConfigUrlField> InInfo, const TSharedRef<STableViewBase>& OwnerTable)
{
	return SNew(STableRow<TSharedPtr<FConfigUrlField>>, OwnerTable)
		.Padding(FMargin(2.f, 1.f, 2.f, 1.f))
		.Content()
		[
			SNew(STextBlock)
			.Text(FText::FromString(InInfo->Name))
		];
}

void FPropertyTypeCustomization_GameBasicConfigUrl::OnGetChildren(TSharedPtr<FConfigUrlField> InField, TArray< TSharedPtr<FConfigUrlField> >& OutChildren)
{
	OutChildren = InField->Children;
}

void FPropertyTypeCustomization_GameBasicConfigUrl::OnSelectionChanged(TSharedPtr<FConfigUrlField> InField, ESelectInfo::Type SelectInfo)
{
	if (InField->Children.IsEmpty()) {
		if (InField->Name == "None") {
			URL->URL.Reset();
		}
		else {
			FString Url = InField->Name;
			FConfigUrlField* Parent = InField->Parent;
			while (Parent)
			{
				Url = Parent->Name + "." + Url;
				Parent = Parent->Parent;
			}
			URL->URL = Url;
			mPropertyHandle->NotifyPostChange(EPropertyChangeType::ValueSet);
			mPropertyHandle->NotifyFinishedChangingProperties();
		}
		FSlateApplication::Get().DismissAllMenus();
	}
}

bool FPropertyTypeCustomization_GameBasicConfigUrl::IsSelectableOrNavigable(TSharedPtr<FConfigUrlField> InField) const
{
	return true;
}
