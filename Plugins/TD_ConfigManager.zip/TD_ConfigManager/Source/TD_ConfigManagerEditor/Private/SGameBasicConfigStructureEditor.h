#pragma once

#include "Widgets/SCompoundWidget.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Input/STextComboBox.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Layout/SWidgetSwitcher.h"
#include "BlueprintEditor.h"
#include "Engine/DataAsset.h"
#include "GameBasicConfigStructureBlueprint.h"

class SGameBasicConfigStructureEditor: public SCompoundWidget, public FGCObject
{
public:
	SLATE_BEGIN_ARGS(SGameBasicConfigStructureEditor) {}
	SLATE_END_ARGS()
public:
	void Construct(const FArguments& InArgs, FBlueprintEditor* InEditor);
	UGameBasicConfigStructureBlueprint* GetEditorBlueprint();
protected:
	void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual FString GetReferencerName() const override { return TEXT("LuaTabulatingTool"); }
	TSharedRef<ITableRow> OnGenerateRow(UObject* InInfo, const TSharedRef<STableViewBase>& OwnerTable);
	void OnSelectionChanged(UObject* Instance, ESelectInfo::Type Info);
	FReply OnBtCreateClicked();
	FReply OnBtSaveAllClicked();
	FReply OnBtRefreshClicked();
	void OnBlueprintCompiled(UBlueprint* InBlueprint);
	FString OnItemDebug(UObject* Instance);

	void Load();
	void Save(bool bShowNotify = false);
	void BrowseToCsvFile();
	void BrowseToLuaFile();
	void CreateNewRow();
	void RemoveRows(TArray<UObject*> Instance);
	FString RunCsvExportTool();
	FString GetRowKeyName(UObject* Row);
	void TrySortInstanceList();
protected:
	FBlueprintEditor* mEditor;
	TSharedPtr<SBox> mViewBox;
	TSharedPtr<SListView<UObject*>> mInstanceView;
	TArray<UObject*> mInstanceList;
	TSharedPtr<IDetailsView> mDetailsView;
	TSharedPtr<SButton> mBtSave;
};