#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FGameBasicConfigStructureBlueprintAssetActions;

class FTD_ConfigManagerEditorModule : public IModuleInterface
{
public:
	static FORCEINLINE FTD_ConfigManagerEditorModule& Get() {
		return FModuleManager::LoadModuleChecked<FTD_ConfigManagerEditorModule>("GameBasicEditor");
	}
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
private:
	TSharedPtr<FGameBasicConfigStructureBlueprintAssetActions> mConfigStructureAssetActions;
};
